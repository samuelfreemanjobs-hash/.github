#!/usr/bin/env bash
# Pre-launch static verification (no API keys required)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
FAIL=0

echo "🔎 HUNTER launch verification"
echo "=============================="

for f in .env.example Dockerfile docker-compose.yml railway.json \
  supabase/migration-full.sql supabase/migration-v3-outreach.sql \
  GO_LIVE_RUNBOOK.md LAUNCH_STATUS.md business/LAUNCH_CHECKLIST.md; do
  if [[ -f "$f" ]]; then
    echo "  ✅ $f"
  else
    echo "  ❌ missing: $f"
    FAIL=$((FAIL + 1))
  fi
done

echo ""
echo "n8n workflows:"
for f in n8n/*.json; do
  if python3 -m json.tool "$f" > /dev/null 2>&1; then
    echo "  ✅ $(basename "$f")"
  else
    echo "  ❌ invalid JSON: $f"
    FAIL=$((FAIL + 1))
  fi
done

echo ""
echo "Frontend entrypoints:"
for f in frontend/index.html frontend/operator.html frontend/hunter_crm.html; do
  [[ -f "$f" ]] && echo "  ✅ $f" || { echo "  ❌ missing $f"; FAIL=$((FAIL + 1)); }
done

if [[ $FAIL -eq 0 ]]; then
  echo ""
  echo "✅ Static launch verification passed"
  exit 0
fi
echo ""
echo "⚠️  $FAIL issue(s) — fix before go-live"
exit 1
