# START HERE — Revenue Pipeline System

**Digital download · Not a physical item · White-label as [YOUR BRAND]**

Thank you for your purchase. This is the **Revenue Pipeline System**: CRM, lead scoring, outreach templates, landing page, and automation files you run on your own computer or cloud account.

---

## What you received

| Part | Location |
|------|----------|
| App (API + CRM + landing) | `server.js`, `frontend/`, `lib/` |
| 10 leads + email copy | `data/seed-leads.json` → `npm run seed` |
| PDF outreach assets (4 leads) | `content/give-before-ask/` |
| LinkedIn post #1 | `content/linkedin-post-001.md` |
| Go-live guide | `GO_LIVE_RUNBOOK.md` |
| Pricing & contracts | `business/PRICING.md`, `templates/` |
| Automation | `n8n/` |

---

## Quick start (30 minutes)

### Requirements

- **Node.js 20+**
- Optional: Supabase, Gemini, Resend, Cal.com (see `.env.example`)

### Install & run

```bash
npm ci
cp .env.example .env
```

Edit `.env`:

- `OPERATOR_BRAND=[YOUR BRAND]`
- `BOOKING_URL=` your Cal.com or Calendly link

```bash
npm start
```

Open:

- Landing: http://localhost:3001/
- CRM: http://localhost:3001/hunter_crm.html
- Dashboard: http://localhost:3001/operator.html

```bash
npm run seed
npm run health
```

---

## Branding

See `WHITE_LABEL-BUYER.md`. Set **your** name — not the product name — on client-facing emails unless you sell as “Revenue Pipeline System.”

---

## License

Read `DIGITAL-LICENSE.txt`. No resale or re-listing of these files on Etsy or elsewhere.

---

## Support

Self-serve: `GO_LIVE_RUNBOOK.md` and `npm run health`.  
Contact the shop via Etsy messages if your listing includes support.
