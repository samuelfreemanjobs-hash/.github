# Buyer FAQ (include in listing or shop policies)

**Is this a physical product?**  
No. Instant digital download (ZIP). Etsy will provide a download link after purchase.

**Do I need to code?**  
Basic comfort with Terminal/command line helps. Steps are copy-paste in START_HERE.md. No coding required for the first local test.

**What do I need to pay monthly?**  
Optional: Supabase free tier, Railway/Render (~$5+), Resend, Gemini API. You can test locally with $0.

**Can I sell this on Etsy again?**  
No. See DIGITAL-LICENSE.txt — use it to run **your** consulting pipeline, not to resell the files.

**What niche is this for?**  
Built for **operational intelligence / systems consulting** targeting manufacturers (CNC, stamping, 3PL, etc.). Rebrand and adapt copy for your niche.

**Refunds?**  
Per your shop policy. Digital items are usually non-refundable once downloaded (Etsy policy).

**Updates?**  
If the seller offers lifetime updates, check the shop announcement; otherwise you receive the version at purchase time.
