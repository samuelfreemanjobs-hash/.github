#!/usr/bin/env bash
# Build ZIP for Etsy digital download (buyer-facing).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ETSY="$ROOT/etsy-digital-product"
STAGING="$ROOT/dist/etsy-staging"
OUT="$ROOT/dist"
DATE="$(date +%Y%m%d)"
ZIP="$OUT/revenue-pipeline-system-etsy-digital.zip"
MAX_MB=20

cd "$ROOT"
mkdir -p "$STAGING" "$OUT"
rm -rf "$STAGING"
mkdir -p "$STAGING"

echo "📦 Building Etsy buyer ZIP..."

# PDF guides (Etsy buyers open these first)
if [[ -x "$ETSY/scripts/build-buyer-pdfs.sh" ]]; then
  bash "$ETSY/scripts/build-buyer-pdfs.sh" || echo "⚠️  PDF build had warnings — continuing"
fi
if [[ -d "$ETSY/pdf-exports" ]] && ls "$ETSY/pdf-exports"/*.pdf >/dev/null 2>&1; then
  mkdir -p "$STAGING/00-PDF-Guides"
  cp "$ETSY/pdf-exports"/*.pdf "$STAGING/00-PDF-Guides/"
  echo "  📄 Included $(ls -1 "$STAGING/00-PDF-Guides"/*.pdf | wc -l) PDF(s) in 00-PDF-Guides/"
fi

# Buyer entrypoints first
cp "$ETSY/START_HERE.md" "$STAGING/START_HERE.md"
cp "$ETSY/DIGITAL-LICENSE.txt" "$STAGING/DIGITAL-LICENSE.txt"
cp "$ETSY/BUYER-FAQ.md" "$STAGING/BUYER-FAQ.md"
cp "$ETSY/WHITE_LABEL-BUYER.md" "$STAGING/WHITE_LABEL-BUYER.md"
mkdir -p "$STAGING/etsy-digital-product"
cp "$ETSY/WHITE_LABEL-BUYER.md" "$STAGING/etsy-digital-product/"

copy() { [[ -e "$ROOT/$1" ]] && cp -a "$ROOT/$1" "$STAGING/$1"; }

copy server.js
copy package.json
copy package-lock.json
copy .env.example
copy Dockerfile
copy docker-compose.yml
copy railway.json
copy README.md
copy GO_LIVE_RUNBOOK.md
copy LAUNCH_STATUS.md

cp -a "$ROOT/lib" "$STAGING/lib"
cp -a "$ROOT/frontend" "$STAGING/frontend"
cp -a "$ROOT/scripts" "$STAGING/scripts"
mkdir -p "$STAGING/data"
copy data/seed-leads.json
cp -a "$ROOT/supabase" "$STAGING/supabase"
cp -a "$ROOT/n8n" "$STAGING/n8n"
cp -a "$ROOT/content" "$STAGING/content"
cp -a "$ROOT/business" "$STAGING/business"
cp -a "$ROOT/templates" "$STAGING/templates"
cp -a "$ROOT/prompts" "$STAGING/prompts"
cp -a "$ETSY/scripts" "$STAGING/etsy-digital-product/scripts"

# Exclude seller-only assets (listing copy stays in repo, not in buyer zip)
# ETSY-LISTING.md, SELLER-CHECKLIST.md, ETSY-KEYWORD-PASS.md — NOT copied

rm -f "$ZIP"
(cd "$STAGING" && zip -rq "$ZIP" .)
rm -rf "$STAGING"

SIZE_MB="$(du -m "$ZIP" | cut -f1)"
echo "✅ $ZIP (${SIZE_MB} MB)"
if [[ "$SIZE_MB" -gt "$MAX_MB" ]]; then
  echo "❌ Over Etsy ${MAX_MB}MB limit — trim content or split download"
  exit 1
fi
