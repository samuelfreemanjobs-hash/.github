#!/usr/bin/env bash
# Generate buyer-facing PDFs for Etsy ZIP (run before build-etsy).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ETSY="$ROOT/etsy-digital-product"
GUIDES="$ETSY/buyer-guides"
OUT="$ETSY/pdf-exports"
GBA="$ROOT/content/give-before-ask"
CHROME="${CHROME_BIN:-google-chrome}"

cd "$ROOT"
mkdir -p "$OUT"
rm -f "$OUT"/*.pdf

VIDEO_URL="https://REPLACE_WITH_YOUR_UNLISTED_VIDEO_LINK"
if [[ -f "$ROOT/WALKTHROUGH-VIDEO.txt" ]]; then
  v="$(grep -E '^VIDEO_URL=' "$ROOT/WALKTHROUGH-VIDEO.txt" | head -1 | cut -d= -f2-)"
  [[ -n "$v" ]] && VIDEO_URL="$v"
fi

echo "📄 Building buyer PDFs → $OUT"

mdpdf() {
  local src="$1"
  local dest="$2"
  (cd "$(dirname "$src")" && npx --yes md-to-pdf "$(basename "$src")")
  local generated="${src%.md}.pdf"
  [[ -f "$generated" ]] || { echo "  ⚠️  no PDF for $src"; return 1; }
  mv -f "$generated" "$dest"
  echo "  ✅ $(basename "$dest")"
}

htmlpdf() {
  local html="$1"
  local dest="$2"
  local abs
  abs="$(cd "$(dirname "$html")" && pwd)/$(basename "$html")"
  if ! command -v "$CHROME" >/dev/null 2>&1; then
    echo "  ⚠️  Chrome not found — skip $(basename "$dest")"
    return 0
  fi
  local udir="/tmp/chrome-pdf-$$-$(basename "$dest")"
  timeout 45 "$CHROME" --headless=new --disable-gpu --no-sandbox \
    --user-data-dir="$udir" \
    --no-pdf-header-footer \
    --print-to-pdf="$dest" "file://${abs}" 2>/dev/null || true
  if [[ -s "$dest" ]]; then
    echo "  ✅ $(basename "$dest")"
  else
    echo "  ⚠️  print failed $(basename "$html")"
  fi
  rm -rf "$udir"
}

mdpdf "$GUIDES/PDF-ONLY-PATH.md" "$OUT/00-PDF-Only-Path.pdf" || true
mdpdf "$GUIDES/INSTALL-NODE-MAC-WINDOWS.md" "$OUT/02-Install-Node-Mac-Windows.pdf" || true

TMP_START="$OUT/_quick-start.md"
{
  cat "$ETSY/START_HERE.md"
  echo ""
  echo "---"
  echo ""
  echo "## Video walkthrough (3–5 minutes)"
  echo ""
  if [[ "$VIDEO_URL" == *REPLACE_WITH* ]]; then
    echo "Ask the shop owner for the walkthrough link, or see \`WALKTHROUGH-VIDEO.txt\` in the ZIP after they publish the video."
  else
    echo "Visual tour of the PDF folder, outreach pack, and CRM:"
    echo ""
    echo "**${VIDEO_URL}**"
  fi
} > "$TMP_START"
mdpdf "$TMP_START" "$OUT/01-Quick-Start.pdf" || true
rm -f "$TMP_START"

TMP_FAQ="$OUT/_faq-license.md"
{
  echo "# Buyer FAQ"
  cat "$ETSY/BUYER-FAQ.md"
  echo ""
  echo "---"
  echo ""
  echo "# Digital license"
  cat "$ETSY/DIGITAL-LICENSE.txt"
} > "$TMP_FAQ"
mdpdf "$TMP_FAQ" "$OUT/03-Buyer-FAQ-and-License.pdf" || true
rm -f "$TMP_FAQ"

mdpdf "$ROOT/content/outreach-batch-001.md" "$OUT/04-Outreach-Batch-1.pdf" || true
mdpdf "$ROOT/content/linkedin-post-001.md" "$OUT/09-LinkedIn-Post-1.pdf" || true

htmlpdf "$GBA/true-industries-die-tryout-tracker.html" "$OUT/05-Give-Before-Ask-True-Industries.pdf"
htmlpdf "$GBA/auto-metal-craft-ecn-laser-queue.html" "$OUT/06-Give-Before-Ask-Auto-Metal-Craft.pdf"
htmlpdf "$GBA/barron-casting-spindle-ndt-tracker.html" "$OUT/07-Give-Before-Ask-Barron-Industries.pdf"
htmlpdf "$GBA/fitzpatrick-spindle-cmm-queue.html" "$OUT/08-Give-Before-Ask-Fitzpatrick.pdf"

count="$(ls -1 "$OUT"/*.pdf 2>/dev/null | wc -l)"
echo "Done. ${count} PDF(s) in pdf-exports/"
