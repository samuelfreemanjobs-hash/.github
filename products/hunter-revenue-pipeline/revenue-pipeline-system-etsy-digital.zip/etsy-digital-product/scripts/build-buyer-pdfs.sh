#!/usr/bin/env bash
# Generate buyer-facing PDFs for Etsy ZIP (run before build-etsy).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ETSY="$ROOT/etsy-digital-product"
OUT="$ETSY/pdf-exports"
GBA="$ROOT/content/give-before-ask"
CHROME="${CHROME_BIN:-google-chrome}"

cd "$ROOT"
mkdir -p "$OUT"
rm -f "$OUT"/*.pdf

echo "📄 Building buyer PDFs → $OUT"

mdpdf() {
  local src="$1"
  local dest="$2"
  npx --yes md-to-pdf "$src"
  local generated="${src%.md}.pdf"
  [[ -f "$generated" ]] || { echo "  ⚠️  no PDF for $src"; return 1; }
  mv -f "$generated" "$dest"
  echo "  ✅ $(basename "$dest")"
}

htmlpdf() {
  local html="$1"
  local dest="$2"
  local abs
  abs="$(cd "$(dirname "$html")" && pwd)/$(basename "$html")"
  if ! command -v "$CHROME" >/dev/null 2>&1; then
    echo "  ⚠️  Chrome not found — skip $(basename "$dest")"
    return 0
  fi
  local udir="/tmp/chrome-pdf-$$-$(basename "$dest")"
  timeout 45 "$CHROME" --headless=new --disable-gpu --no-sandbox \
    --user-data-dir="$udir" \
    --no-pdf-header-footer \
    --print-to-pdf="$dest" "file://${abs}" 2>/dev/null || true
  if [[ -s "$dest" ]]; then
    echo "  ✅ $(basename "$dest")"
  else
    echo "  ⚠️  print failed $(basename "$html")"
  fi
  rm -rf "$udir"
}

mdpdf "$ETSY/START_HERE.md" "$OUT/01-Quick-Start.pdf" || true

TMP_FAQ="$OUT/_faq-license.md"
{
  echo "# Buyer FAQ"
  cat "$ETSY/BUYER-FAQ.md"
  echo ""
  echo "---"
  echo ""
  echo "# Digital license"
  cat "$ETSY/DIGITAL-LICENSE.txt"
} > "$TMP_FAQ"
mdpdf "$TMP_FAQ" "$OUT/02-Buyer-FAQ-and-License.pdf" || true
rm -f "$TMP_FAQ"

mdpdf "$ROOT/content/outreach-batch-001.md" "$OUT/03-Outreach-Batch-1.pdf" || true
mdpdf "$ROOT/content/linkedin-post-001.md" "$OUT/08-LinkedIn-Post-1.pdf" || true

htmlpdf "$GBA/true-industries-die-tryout-tracker.html" "$OUT/04-Give-Before-Ask-True-Industries.pdf"
htmlpdf "$GBA/auto-metal-craft-ecn-laser-queue.html" "$OUT/05-Give-Before-Ask-Auto-Metal-Craft.pdf"
htmlpdf "$GBA/barron-casting-spindle-ndt-tracker.html" "$OUT/06-Give-Before-Ask-Barron-Industries.pdf"
htmlpdf "$GBA/fitzpatrick-spindle-cmm-queue.html" "$OUT/07-Give-Before-Ask-Fitzpatrick.pdf"

count="$(ls -1 "$OUT"/*.pdf 2>/dev/null | wc -l)"
echo "Done. ${count} PDF(s) in pdf-exports/"
