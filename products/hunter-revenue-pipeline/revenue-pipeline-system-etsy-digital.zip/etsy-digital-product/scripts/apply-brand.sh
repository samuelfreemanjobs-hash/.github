#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BRAND="${1:?Usage: $0 'Your Brand'}"
cd "$ROOT"
for f in frontend/index.html etsy-digital-product/START_HERE.md; do
  [[ -f "$f" ]] && sed -i "s/\[YOUR BRAND\]/${BRAND}/g" "$f"
done
grep -q "^OPERATOR_BRAND=" .env 2>/dev/null && sed -i "s/^OPERATOR_BRAND=.*/OPERATOR_BRAND=${BRAND}/" .env || true
echo "Updated brand to: $BRAND — grep -ri HUNTER frontend content templates"
