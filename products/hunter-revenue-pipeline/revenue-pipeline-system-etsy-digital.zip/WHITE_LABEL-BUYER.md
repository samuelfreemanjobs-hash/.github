# White-label — Revenue Pipeline System

The **product name** is Revenue Pipeline System. **Your clients** should see **[YOUR BRAND]** on emails and the landing page.

## Required (.env)

```
OPERATOR_BRAND=Your Name or Agency
RESEND_FROM=Your Brand <you@yourdomain.com>
BOOKING_URL=https://cal.com/you/diagnostic
PUBLIC_URL=https://your-deployed-url.com
```

## Edit these files

| File | Change |
|------|--------|
| `frontend/index.html` | Logo, headline, footer |
| `frontend/hunter_crm.html` | Header title |
| `content/give-before-ask/*.html` | `.brand` and footer — use [YOUR BRAND] |
| `templates/msa-template.md` | Provider name |
| `business/PRICING.md` | Your prices (optional) |

## Helper

```bash
bash etsy-digital-product/scripts/apply-brand.sh "Your Brand Name"
```
