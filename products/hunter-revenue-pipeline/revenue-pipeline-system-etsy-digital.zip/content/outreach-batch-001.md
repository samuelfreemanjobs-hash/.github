# Unified Outreach Batch #1 — 10 Leads

**Source of truth:** `data/seed-leads.json` + `content/gtm/manifest.yaml`  
**Status:** Ready — replace `[BOOKING_URL]` via `BOOKING_URL` in `.env` (seed substitutes automatically)  
**Brand:** set `OPERATOR_BRAND` in `.env` for white-label sign-off

| Rank | Company | Tier | PDF attachment |
|------|---------|------|----------------|
| 1 | True Industries, Inc. | HOT | `give-before-ask/true-industries-die-tryout-tracker.html` → PDF |
| 2 | Auto Metal Craft | HOT | `auto-metal-craft-ecn-laser-queue.html` → PDF |
| 3 | Barron Industries | HOT | `barron-casting-spindle-ndt-tracker.html` → PDF |
| 4 | Fitzpatrick Manufacturing Co. | HOT | `fitzpatrick-spindle-cmm-queue.html` → PDF |
| 5 | Great Lakes Aerospace Components | HOT | — |
| 6 | Heartland 3PL Logistics | HIGH | — |
| 7 | Midwest Stamping & Tool | HIGH | — |
| 8 | Titan Metal Works | HIGH | — |
| 9 | Carolina Fabrication Group | HIGH | — |
| 10 | Atlas Wire Technologies | HIGH | — |

**CRM:** Run `npm run seed` — outreach subject/body and `give_before_ask` paths load into each lead.

**Hub:** http://localhost:3001/content/give-before-ask/ (ranks 1–4)

---

## 1. True Industries, Inc. — HOT (95)

**To:** vp.operations@trueindustries.com  
**Subject:** I attached a 1-page tryout tracker for True Industries  
**Attach:** PDF from `true-industries-die-tryout-tracker.html`

(See CRM Outreach tab for full body after seed.)

---

## 2. Auto Metal Craft — HOT (95)

**To:** ckarch@autometalcraft.com  
**Subject:** ECN laser queue — quick framework for Auto Metal Craft  
**Attach:** PDF from `auto-metal-craft-ecn-laser-queue.html`

---

## 3. Barron Industries — HOT (95)

**To:** ops@barronindustries.com  
**Subject:** Foundry-to-5-axis — spindle & NDT tracker for Barron  
**Attach:** PDF from `barron-casting-spindle-ndt-tracker.html`

---

## 4. Fitzpatrick Manufacturing Co. — HOT (94)

**To:** plant.manager@fitzpatrickmfg.com  
**Subject:** CMM queue + spindle bridge — framework for Fitzpatrick  
**Attach:** PDF from `fitzpatrick-spindle-cmm-queue.html`

---

## 5–10. Great Lakes Aerospace through Atlas Wire

Full copy lives in `data/seed-leads.json` (`outreachSubject` / `outreachBody`). After `npm run seed`, open **CRM → Outreach** on each lead or use `POST /api/outreach/batch` with `dryRun: true`.

**Send order:** ranks 5 → 10 per `content/gtm/manifest.yaml`.
