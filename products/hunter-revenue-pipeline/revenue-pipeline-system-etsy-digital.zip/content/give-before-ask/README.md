# Give-Before-Ask Assets

These four frameworks match **unified GTM ranks 1–4** in `content/gtm/manifest.yaml` and `data/seed-leads.json`. The CRM stores the path on each lead as `give_before_ask`.

## Files

| Rank | Company | File | CRM seed |
|------|---------|------|----------|
| 1 | True Industries | `true-industries-die-tryout-tracker.html` | ✅ |
| 2 | Auto Metal Craft | `auto-metal-craft-ecn-laser-queue.html` | ✅ |
| 3 | Barron Industries | `barron-casting-spindle-ndt-tracker.html` | ✅ |
| 4 | Fitzpatrick Manufacturing | `fitzpatrick-spindle-cmm-queue.html` | ✅ |

Leads **5–10** use email-only outreach (no PDF in this folder yet).

## Export to PDF

1. Open the `.html` file in Chrome or Edge
2. `Ctrl+P` / `Cmd+P` → **Save as PDF**
3. Background graphics: **ON**
4. Attach to the email for that rank (copy in CRM after `npm run seed`)

## When deployed

```
https://YOUR-DOMAIN/content/give-before-ask/
```

Index lists all four; paths match CRM `give_before_ask` values.
